package com.cts.demoChatApplication.model;

public enum MessageType {

		CHAT,LEAVE,JOIN
}
